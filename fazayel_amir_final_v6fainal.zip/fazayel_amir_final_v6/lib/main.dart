import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green=Color(0xFF075B3C), gold=Color(0xFFD5A62A), cream=Color(0xFFF8F1DF), card=Color(0xFFFFFBF2);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final p=await SharedPreferences.getInstance();
  runApp(App(dark:p.getBool('dark')??false,favorites:(p.getStringList('favorites')??[]).map(int.parse).toSet()));
}

class App extends StatefulWidget {
  final bool dark; final Set<int> favorites;
  const App({super.key,required this.dark,required this.favorites});
  State<App> createState()=>_AppState();
}

class _AppState extends State<App>{
  late bool dark; late Set<int> favorites;
  void initState(){super.initState();dark=widget.dark;favorites={...widget.favorites};}
  Future<void> fav(int id) async { setState(()=>favorites.contains(id)?favorites.remove(id):favorites.add(id)); final p=await SharedPreferences.getInstance(); await p.setStringList('favorites',favorites.map((e)=>'$e').toList()); }
  Future<void> setDark(bool v) async { setState(()=>dark=v); final p=await SharedPreferences.getInstance(); await p.setBool('dark',v); }
  ThemeData get theme=>ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:green,brightness:dark?Brightness.dark:Brightness.light),scaffoldBackgroundColor:dark?const Color(0xFF121815):cream);
  Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'فضائل امیرالمؤمنین',theme:theme,home:Splash(onDone:()=>Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>Home(favorites:favorites,onFav:fav,dark:dark,onDark:setDark)))));
}

class Splash extends StatefulWidget{final VoidCallback onDone;const Splash({super.key,required this.onDone});State<Splash> createState()=>_SplashState();}

class _SplashState extends State<Splash>{
  void initState(){super.initState();Future.delayed(const Duration(milliseconds:1000),(){if(mounted)widget.onDone();});}
  Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(backgroundColor:green,body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:150,height:150,padding:const EdgeInsets.all(12),decoration:BoxDecoration(borderRadius:BorderRadius.circular(38),border:Border.all(color:gold,width:4)),child:Image.asset('assets/logo.svg')),const SizedBox(height:24),const Text('فضائل امیرالمؤمنین',style:TextStyle(color:Color(0xFFFFE7A3),fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('علی بن ابی‌طالب علیه‌السلام',style:TextStyle(color:Colors.white,fontSize:18))]))));
}

class Home extends StatefulWidget{
 final Set<int> favorites; final Future<void> Function(int) onFav; final bool dark; final Future<void> Function(bool) onDark;
 const Home({super.key,required this.favorites,required this.onFav,required this.dark,required this.onDark});
 State<Home> createState()=>_HomeState();
}

class _HomeState extends State<Home>{
  int tab=0;String q='';List<Map<String,dynamic>> items=[];
 void initState(){super.initState();load();}
 Future<void> load()async{final raw=await rootBundle.loadString('lib/data/fazayel_110.json');setState(()=>items=(jsonDecode(raw) as List).cast<Map<String,dynamic>>());}
 List<Map<String,dynamic>> filter(List<Map<String,dynamic>> s){final x=q.trim();if(x.isEmpty)return s;return s.where((e)=>'${e['id']} ${e['summary']}'.contains(x)).toList();}
 void open(Map<String,dynamic>x)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Detail(item:x,isFav:widget.favorites.contains(x['id']),onFav:()=>widget.onFav(x['id']))));
 Widget search()=>Padding(padding:const EdgeInsets.fromLTRB(16,16,16,8),child:TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(hintText:'جستجو در ۱۱۰ فضیلت...',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Theme.of(context).cardColor,border:OutlineInputBorder(borderRadius:BorderRadius.circular(18),borderSide:BorderSide.none))));
 Widget stat(String n,String t,IconData i,VoidCallback f)=>Expanded(child:InkWell(onTap:f,borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Theme.of(context).cardColor,borderRadius:BorderRadius.circular(18),border:Border.all(color:gold.withOpacity(.6))),child:Row(children:[CircleAvatar(backgroundColor:green,foregroundColor:const Color(0xFFFFE7A3),child:Icon(i)),const SizedBox(width:9),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(n,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:green)),Text(t)])]))));
 Widget home()=>items.isEmpty?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(color:green,borderRadius:BorderRadius.circular(25)),child:Column(children:[Container(width:76,height:76,padding:const EdgeInsets.all(5),decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),border:Border.all(color:gold,width:2)),child:Image.asset('assets/logo.svg')),const SizedBox(height:9),const Text('فضائل امیرالمؤمنین',style:TextStyle(color:Color(0xFFFFE7A3),fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('علی بن ابی‌طالب علیه‌السلام',style:TextStyle(color:Colors.white,fontSize:17)),const SizedBox(height:5),const Text('گنجینه‌ای از فضائل و مناقب امیرالمؤمنین',textAlign:TextAlign.center,style:TextStyle(color:Colors.white70))]),),search(),Row(children:[stat('۱۱۰','فضیلت',Icons.menu_book,()=>setState(()=>tab=1)),const SizedBox(width:10),stat('${widget.favorites.length}','ذخیره‌شده',Icons.favorite,()=>setState(()=>tab=2))]),const SizedBox(height:16),Card(color:Theme.of(context).cardColor,child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[const Text('فضیلت منتخب',style:TextStyle(color:green,fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:10),Text(items.first['summary'],textAlign:TextAlign.center,style:const TextStyle(fontSize:16,height:1.9)),const SizedBox(height:10),FilledButton(onPressed:()=>open(items.first),child:const Text('مطالعه فضیلت'))]))) ]);
 
 Widget listPage(List<Map<String,dynamic>> src,{String empty=''}){
   final list=filter(src);
   if(list.isEmpty) return Column(children:[search(),Expanded(child:Center(child:Text(empty.isEmpty?'موردی پیدا نشد':empty)))]);
   return Column(children:[
     search(),
     Expanded(child:ListView.builder(
       padding:const EdgeInsets.all(16),
       itemCount:list.length,
       itemBuilder:(c,i) { // پرانتز اضافه‌شده در اینجا
         final x=list[i],id=x['id'] as int,is=widget.favorites.contains(id);
         return Card(
           color:Theme.of(context).cardColor,
           margin:const EdgeInsets.only(bottom:10),
           shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17)),
           child:ListTile(
             leading:CircleAvatar(backgroundColor:green,foregroundColor:const Color(0xFFFFE7A3),child:Text('$id')),
             title:Text('فضیلت شماره $id',style:const TextStyle(fontWeight:FontWeight.bold)),
             subtitle:Text(x['summary'],maxLines:2,overflow:TextOverflow.ellipsis),
             trailing:IconButton(icon:Icon(is?Icons.favorite:Icons.favorite_border,color:is?Colors.red:null),onPressed:()=>widget.onFav(id)),
             onTap:()=>open(x)
           )
         );
       }
     ))
   ]);
 }
 
 Widget settings()=>ListView(padding:const EdgeInsets.all(16),children:[Card(color:Theme.of(context).cardColor,child:SwitchListTile(value:widget.dark,onChanged:widget.onDark,title:const Text('حالت شب'),secondary:const Icon(Icons.dark_mode,color:green))),const SizedBox(height:10),Card(color:Theme.of(context).cardColor,child:const ListTile(leading:Icon(Icons.info_outline,color:green),title:Text('نسخه برنامه'),subtitle:Text('1.0.0+6'))),const SizedBox(height:10),Card(color:Theme.of(context).cardColor,child:const ListTile(leading:Icon(Icons.book,color:green),title:Text('منبع اولیه'),subtitle:Text('صفحه ۱۱۰ فضیلت'))) ]);
 
 Widget build(BuildContext c){
   final body=tab==0?home():tab==1?listPage(items):tab==2?listPage(items.where((x)=>widget.favorites.contains(x['id'])).toList(),empty:'هنوز مطلبی ذخیره نشده است.'):settings();
   return Directionality(textDirection:TextDirection.rtl,child:Scaffold(
     appBar:AppBar(backgroundColor:green,foregroundColor:const Color(0xFFFFE7A3),centerTitle:true,title:Text(['خانه','فضائل','علاقه‌مندی‌ها','تنظیمات'][tab],style:const TextStyle(fontWeight:FontWeight.bold))),
     body:body,
     bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
       NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'خانه'),
       NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'فضائل'),
       NavigationDestination(icon:Icon(Icons.favorite_border),selectedIcon:Icon(Icons.favorite),label:'علاقه‌مندی'),
       NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'تنظیمات')
     ])
   ));
 }
}

class Detail extends StatelessWidget{
  final Map<String,dynamic> item;final bool isFav;final VoidCallback onFav;
  const Detail({super.key,required this.item,required this.isFav,required this.onFav});
  String get text=>'فضیلت شماره ${item['id']}\n\n${item['summary']}\n\nمنبع اولیه: ${item['source_page']}';
  Widget build(BuildContext c)=>Directionality(textDirection:TextDirection.rtl,child:Scaffold(
    appBar:AppBar(backgroundColor:green,foregroundColor:const Color(0xFFFFE7A3),title:Text('فضیلت ${item['id']}'),actions:[
      IconButton(onPressed:onFav,icon:Icon(isFav?Icons.favorite:Icons.favorite_border)),
      IconButton(onPressed:()=>Share.share(text),icon:const Icon(Icons.share))
    ]),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      Card(color:Theme.of(c).cardColor,child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
        CircleAvatar(radius:28,backgroundColor:green,foregroundColor:const Color(0xFFFFE7A3),child:Text('${item['id']}')),
        const SizedBox(height:12),
        Text('فضیلت شماره ${item['id']}',style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:green)),
        const SizedBox(height:15),
        Text(item['summary'],style:const TextStyle(fontSize:17,height:2),textAlign:TextAlign.justify)
      ]))),
      const SizedBox(height:16),
      const Text('منبع اولیه',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold,color:green)),
      const SizedBox(height:8),
      Text(item['source_page']),
      const SizedBox(height:16),
      Row(children:[
        Expanded(child:FilledButton.icon(onPressed:()=>Clipboard.setData(ClipboardData(text:text)),icon:const Icon(Icons.copy),label:const Text('کپی'))),
        const SizedBox(width:10),
        Expanded(child:OutlinedButton.icon(onPressed:()=>Share.share(text),icon:const Icon(Icons.share),label:const Text('اشتراک‌گذاری')))
      ])
    ])
  ));
}